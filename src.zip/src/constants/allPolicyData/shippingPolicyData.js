// src/constants/allPolicyData/shippingPolicyData.js
export const shippingPolicyData = {
  name: "VELTEX SERVICES PRIVATE LIMITED",
  website: "www.astrotring.com",
  title: "SHIPPING POLICY",
  lastUpdated: "March 2026",
  sections: [
    {
      heading: "1. Introduction",
      body: [
        {
          type: "paragraph",
          text: "This Shipping Policy (hereinafter referred to as the \"Policy\") sets out the terms and conditions governing the dispatch, delivery, and logistics of physical products ordered through the Platform operated by Veltex Services Private Limited (hereinafter referred to as \"Veltex\", \"We\", \"Us\", or \"Our\") at www.astrotring.com (the \"Platform\")."
        },
        {
          type: "paragraph",
          text: "By placing an order for a physical product on the Platform, you (\"User\", \"Customer\", or \"You\") acknowledge that You have read, understood, and agreed to the terms of this Shipping Policy. This Policy applies to all orders placed through the Platform and must be read in conjunction with the Terms and Conditions of Use, the Privacy Policy, and the Refund and Cancellation Policy published on the Platform."
        },
        {
          type: "paragraph",
          text: "Veltex reserves the right to update or amend this Policy at any time without prior notice. The most current version will be published on the Platform. Continued use of the Platform and placement of orders following any amendment shall constitute acceptance of the revised Policy."
        }
      ]
    },
    {
      heading: "2. Logistics and Shipping Partners",
      body: [
        {
          type: "paragraph",
          text: "Veltex partners with reputable and trusted third-party logistics and courier service providers to facilitate the timely and secure delivery of products to Users across India and select international destinations. The choice of courier partner for any specific order shall be at the sole discretion of Veltex, based on factors including the delivery location, product type, and availability of services."
        },
        {
          type: "paragraph",
          text: "Veltex does not directly operate or control the logistics infrastructure of its courier partners. While Veltex endeavours to engage only reliable service providers, it shall not be liable for any delay, loss, or damage caused by the acts or omissions of third-party courier partners, subject to the provisions of this Policy."
        }
      ]
    },
    {
      heading: "3. Order Processing",
      body: [
        {
          type: "paragraph",
          text: "Upon successful placement and confirmation of an order on the Platform, Veltex shall process the order within one (1) to two (2) business days. \"Business days\" for the purposes of this Policy refer to Monday through Saturday, excluding public holidays as observed in India."
        },
        {
          type: "paragraph",
          text: "Order processing includes verification of payment, confirmation of product availability, quality inspection, and preparation of the item for dispatch. Orders placed after business hours, on Sundays, or on public holidays will be picked up for processing on the next available business day."
        },
        {
          type: "paragraph",
          text: "Veltex reserves the right to cancel or hold any order where payment verification is unsuccessful, where the item is found to be unavailable, or where any other issue is identified during the processing stage. Users will be notified in such circumstances, and any amounts charged will be refunded in accordance with the Refund and Cancellation Policy."
        }
      ]
    },
    {
      heading: "4. Dispatch Timelines",
      body: [
        {
          type: "paragraph",
          text: "Subject to successful order processing, products are ordinarily dispatched within twenty-four (24) to forty-eight (48) hours of the completion of the processing stage. Dispatch timelines may vary during peak seasons, festivals, or other periods of high demand, and Veltex shall endeavour to communicate any significant delays to the affected Users."
        },
        {
          type: "paragraph",
          text: "Dispatch is subject to the availability of courier services at the delivery location and may be extended in instances of force majeure, adverse weather conditions, logistical disruptions, or other circumstances beyond the reasonable control of Veltex."
        }
      ]
    },
    {
      heading: "5. Estimated Delivery Timelines",
      body: [
        {
          type: "paragraph",
          text: "The following are the estimated delivery timelines from the date of dispatch. These are indicative timeframes only and are not guaranteed. Actual delivery times may vary based on the courier partner's operations, the delivery location, and external factors beyond Veltex's control."
        },
        {
          type: "table",
          headers: ["Delivery Zone", "Estimated Delivery Time (from dispatch)"],
          rows: [
            ["Metro Cities", "2 – 4 business days"],
            ["Tier 2 & Tier 3 Cities", "4 – 6 business days"],
            ["Remote or Rural Areas", "5 – 8 business days"],
            ["International Orders", "7 – 15 business days (subject to customs clearance)"]
          ]
        },
        {
          type: "paragraph",
          text: "The above timelines are subject to change during peak shopping periods, national holidays, or in the event of disruptions to courier operations. Veltex shall not be held liable for delays falling within the above estimated windows or for delays caused by circumstances beyond its reasonable control."
        }
      ]
    },
    {
      heading: "6. Shipping Coverage",
      subSections: [
        {
          heading: "6.1 Domestic Shipping",
          body: [
            {
              type: "paragraph",
              text: "Veltex ships to all serviceable pin codes across India. To verify whether delivery is available at a specific pin code, Users may contact the customer support team prior to placing an order. In the event that a pin code is found to be non-serviceable after the order has been placed, Veltex will notify the User and arrange for a full refund of the amount paid."
            }
          ]
        },
        {
          heading: "6.2 International Shipping",
          body: [
            {
              type: "paragraph",
              text: "International shipping is currently available for select countries and territories. Users wishing to place international orders are advised to confirm availability for their specific country with Veltex customer support prior to placing an order. International deliveries are subject to customs clearance procedures at the destination country, which may result in additional delays and/or charges."
            },
            {
              type: "paragraph",
              text: "Any customs duties, import taxes, or other levies imposed by the destination country's authorities are the sole responsibility of the recipient. Veltex shall not be liable for delays resulting from customs processing or for any additional charges incurred at the point of importation."
            }
          ]
        }
      ]
    },
    {
      heading: "7. Order Tracking and Shipment Confirmation",
      body: [
        {
          type: "paragraph",
          text: "Upon dispatch of an order, Veltex shall send a shipment confirmation to the User via SMS to the registered mobile number associated with the User's account. The confirmation will include relevant details to enable the User to monitor the status of their delivery."
        },
        {
          type: "paragraph",
          text: "Users may contact Veltex customer support at any time to enquire about the status of their order or to report a delay. Veltex will endeavour to provide timely and accurate information to the best of its ability, subject to information received from the relevant courier partner."
        }
      ]
    },
    {
      heading: "8. Delivery Delays",
      body: [
        {
          type: "paragraph",
          text: "While Veltex makes every reasonable effort to ensure that orders are delivered within the estimated timelines, there may be instances where deliveries are delayed due to circumstances beyond Veltex's control. Such circumstances may include, without limitation:"
        },
        {
          type: "list",
          items: [
            "Adverse weather conditions, natural disasters, or acts of God;",
            "Political disruptions, civil unrest, curfews, or regional restrictions;",
            "Public holidays or festival-related logistical constraints;",
            "Operational delays or errors attributable to the courier partner;",
            "Incorrect, incomplete, or undeliverable address information provided by the User;",
            "Customs clearance delays (for international orders);",
            "Non-availability of the recipient at the time of delivery."
          ]
        },
        {
          type: "paragraph",
          text: "In the event of a significant delay, Veltex shall endeavour to notify the affected User and coordinate with the courier partner to facilitate delivery at the earliest possible date. Users experiencing delivery delays are encouraged to contact Veltex customer support for assistance."
        },
        {
          type: "paragraph",
          text: "Veltex shall not be liable for any loss, damage, or inconvenience arising from delivery delays caused by the above circumstances. However, Veltex will work with the User in good faith to resolve any delivery issues in a reasonable and timely manner."
        }
      ]
    },
    {
      heading: "9. Packaging Standards",
      body: [
        {
          type: "paragraph",
          text: "Veltex is committed to ensuring that all products reach Users in optimal condition. All items are carefully packed prior to dispatch in accordance with the following standards:"
        },
        {
          type: "list",
          items: [
            "All products are inspected for quality prior to packaging.",
            "Fragile or delicate items are individually bubble-wrapped and cushioned to minimise the risk of damage during transit.",
            "All orders are securely sealed before handover to the courier partner.",
            "Packaging materials are selected to provide adequate protection for the nature and weight of the item being shipped."
          ]
        },
        {
          type: "paragraph",
          text: "In the event that a product is received in a damaged condition, Users should contact Veltex customer support within forty-eight (48) hours of delivery, providing photographic evidence of the damaged packaging and product. Veltex will investigate the matter and take appropriate action in accordance with the Refund and Cancellation Policy."
        }
      ]
    },
    {
      heading: "10. Failed Deliveries and Returned Shipments",
      body: [
        {
          type: "paragraph",
          text: "A delivery may be deemed unsuccessful in the following circumstances:"
        },
        {
          type: "list",
          items: [
            "The recipient is unavailable at the delivery address on multiple delivery attempts;",
            "The address provided is incorrect, incomplete, or undeliverable;",
            "The recipient refuses to accept the delivery."
          ]
        },
        {
          type: "paragraph",
          text: "In the event of a failed delivery, the courier partner may make additional delivery attempts or leave a notification for the recipient to arrange re-delivery or collection. If the shipment is returned to Veltex following repeated failed delivery attempts, Veltex will contact the User to arrange re-dispatch, subject to payment of re-shipping charges where applicable. If the User does not respond within a reasonable time, Veltex reserves the right to treat the order as cancelled, and any applicable refund will be processed in accordance with the Refund and Cancellation Policy after deduction of shipping and handling charges."
        },
        {
          type: "paragraph",
          text: "Users are solely responsible for ensuring that accurate and complete delivery information is provided at the time of placing an order. Veltex shall not be responsible for non-delivery arising from incorrect or incomplete address details provided by the User, and no refund shall be payable in such circumstances except at Veltex's sole discretion."
        }
      ]
    },
    {
      heading: "11. Disclaimer and Limitation of Liability",
      body: [
        {
          type: "paragraph",
          text: "Veltex shall use all reasonable efforts to ensure that orders are dispatched and delivered within the timelines specified in this Policy. However, Veltex does not guarantee the delivery of any order within any specific time period and shall not be liable for any direct, indirect, incidental, or consequential loss or damage arising from:"
        },
        {
          type: "list",
          items: [
            "Delays in dispatch or delivery caused by third-party courier partners;",
            "Loss or damage to products during transit;",
            "Delivery failures arising from incorrect or incomplete address information provided by the User;",
            "Delays attributable to customs clearance or regulatory inspections;",
            "Events of force majeure as described in Section 8 of this Policy."
          ]
        },
        {
          type: "paragraph",
          text: "To the extent permitted by applicable law, Veltex's liability to any User in connection with a shipping-related claim shall not exceed the amount paid by the User for the relevant product and its associated shipping charges."
        }
      ]
    },
    {
      heading: "12. Customer Support",
      body: [
        {
          type: "paragraph",
          text: "For any queries, concerns, or assistance relating to shipping, dispatch, or delivery of orders, Users may contact Veltex customer support through the following channels:"
        },
        {
          type: "paragraph",
          text: "Veltex Services Private Limited"
        },
        {
          type: "paragraph",
          text: "Website: www.astrotring.com"
        },
        {
          type: "paragraph",
          text: "Email: care@astrotring.com"
        },
        {
          type: "paragraph",
          text: "Phone: +919485628238 (Available 24 x 7)"
        },
        {
          type: "paragraph",
          text: "Veltex customer support is available twenty-four (24) hours a day, seven (7) days a week, to address any shipping-related concerns. Users are encouraged to have their order details ready when contacting support to enable prompt assistance."
        }
      ]
    },
   
  ]
};